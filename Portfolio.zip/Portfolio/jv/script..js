setInterval(
	function () {
		var randomColor = Math.floor(Math.random()*16777215).toString(16);
		document.getElementById('this').style.backgroundColor = "#"+randomColor;
	},1000);
function enquire(){
	//storing the data from input into these variables
	var name = document.getElementById("name");
	var email_Address = document.getElementById("emailAddress");
	var phone_Number = document.getElementById("phoneNumber");
	var text_Area = document.getElementById("textArea");
	//checking if any of the input fields are empty and if its empty set the border color red and make the labe for invalid visible and also return false statement
	if(name.value.trim()==""){
		document.getElementById("label_invalid").style.visibility="visible";
		return false;
	}
	else if(email_Address.value.trim()==""){
		document.getElementById("label_invalid").style.visibility="visible";
		return false;
	}
	else if(phone_Number.value.trim()==""){
		document.getElementById("label_invalid").style.visibility="visible";
		return false;
	}
	else if(text_Area.value.trim()=="" ){
		document.getElementById("label_invalid").style.visibility="visible";
		return false;
	}
	//if the fields are not empty then set the borders to blue, return true statement and show alert
	else{
		emailAddress.style.border="solid 2px blue";
		phoneNumber.style.border="solid 2px blue";
		textArea.style.border="solid 2px blue"
		true;
		alert("Thank you for commenting >~<.");
	}
}